cut -d , -f 2 $@ | sort | uniq
