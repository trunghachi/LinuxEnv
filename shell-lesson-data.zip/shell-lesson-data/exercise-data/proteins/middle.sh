# remmember that $1 take the first argument
# head -n 15 $1 | tail -5
# head -n $2 "$1" | tail -n $3
head -n $2 $1 | tail -k -n $3
