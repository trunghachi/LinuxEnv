# sort files by the length
# Usage: bash sorted.sh [one or more filenames]
wc -l "$@" | sort -n
